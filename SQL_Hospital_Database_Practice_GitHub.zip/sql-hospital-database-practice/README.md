# SQL Hospital Database Practice

![SQL](https://img.shields.io/badge/SQL-MySQL-blue)
![Practice](https://img.shields.io/badge/Practice-Hospital%20Database-green)
![Level](https://img.shields.io/badge/Levels-Easy%20%7C%20Medium%20%7C%20Hard-orange)

## 📌 Overview

This repository contains my **SQL practice on a Hospital Database**.  
I worked through a structured set of **Easy, Medium, and Hard SQL questions**, covering patient records, admissions, doctors, diagnoses, allergies, dates, aggregations, joins, conditional logic, and analytical queries.

The screenshots below are included as **proof of completed SQL practice**.

---

## 🧠 SQL Concepts Practiced

- `SELECT`
- `WHERE`
- `ORDER BY`
- `DISTINCT`
- `LIKE`
- `IN`
- `NULL` handling
- `BETWEEN`
- `AND` / `OR`
- `COUNT()`
- `SUM()`
- `AVG()`
- `MAX()`
- `MIN()`
- `GROUP BY`
- `HAVING`
- `JOIN`
- `CONCAT()`
- `UPPER()` / `LOWER()`
- `LENGTH()`
- Date functions
- `CASE`
- Subqueries
- Duplicate detection
- Percentage calculations
- Window functions
- Year-wise aggregation

---

## 🟢 Easy Questions Covered

1. Show first name, last name, and gender of male patients.
2. Find patients who do not have allergies (`NULL`).
3. Find patients whose first name starts with `C`.
4. Find patients with weight between 100 and 120 kg.
5. Replace `NULL` allergies with `NKA`.
6. Concatenate first name and last name into a full name.
7. Find admissions where admission and discharge occurred on the same day.
8. Count admissions for `patient_id = 579`.
9. Find unique cities for patients in province `NS`.
10. Find patients with height greater than 160 cm and weight greater than 70 kg.
11. Find Hamilton patients whose allergies are not `NULL`.

---

## 🟡 Medium Questions Covered

12. Find unique first names that occur only once.
13. Find names starting and ending with `s` and having at least 6 characters.
14. Find patients whose primary diagnosis is `Dementia`.
15. Order patient names by length and then alphabetically.
16. Show total male and female patients in the same row.
17. Find patients allergic to `Penicillin` or `Morphine` and sort the results.
18. Find patients admitted multiple times for the same diagnosis.
19. Count patients by city and order from most to least.
20. Combine patients and doctors using a `Patient` / `Doctor` role.
21. Show allergies ordered by popularity while excluding `NKA` and `NULL`.
22. Find patients born in the 1970s and sort by birth date.
23. Display names as `LAST_NAME,first_name` with required case formatting.
24. Find province IDs whose total patient height is at least 7,000.
25. Find the difference between the largest and smallest weight for patients with last name `Maroni`.
26. Count admissions by day of the month and order by admission frequency.
27. Find the most recent admission for `patient_id = 542`.
28. Filter admissions using multiple patient/doctor ID conditions.
29. Show each doctor's first name, last name, and total number of admissions attended.

---

## 🔴 Hard Questions Covered

30. Group patients into 10-kg weight groups and count patients in each group.
31. Calculate `isObese` as `0` or `1` using BMI `>= 30`.
32. Find patients diagnosed with `Dementia` who were attended by a doctor named `Lisa`, including the doctor's specialty.
33. Calculate the percentage of patients whose gender is `M`, rounded to two decimal places and displayed as a percentage.
34. Show the total admissions for each day and the change from the previous date.
35. Sort province names alphabetically while keeping `Ontario` at the top.
36. Create a year-wise breakdown of admissions for each doctor, including:
   - `doctor_id`
   - doctor full name
   - specialty
   - year
   - total admissions

---

## 🔎 Multi-Condition Filtering Practice

I also practiced combining several conditions in one query:

- First name pattern matching
- Gender = `F`
- Birth month = February, May, or December
- Weight between 60 kg and 80 kg
- Odd `patient_id`
- City = `Kingston`

---

# 📸 Practice Screenshots

## Easy SQL Practice

![Easy SQL Questions](screenshots/02-easy-questions.jpeg)

## Medium SQL Practice – 1

![Medium SQL Questions 1](screenshots/03-medium-questions-1.jpeg)

## Medium SQL Practice – 2

![Medium SQL Questions 2](screenshots/04-medium-questions-2.jpeg)

## Medium SQL Practice – 3

![Medium SQL Questions 3](screenshots/05-medium-questions-3.jpeg)

## Medium SQL Practice – 4

![Medium SQL Questions 4](screenshots/06-medium-questions-4.jpeg)

## Medium SQL Practice – 5

![Medium SQL Questions 5](screenshots/07-medium-questions-5.jpeg)

## Medium SQL Practice – 6

![Medium SQL Questions 6](screenshots/08-medium-questions-6.jpeg)

## Hard SQL Practice

![Hard SQL Questions](screenshots/01-hard-questions.jpeg)

---

## 📊 Skills Demonstrated

**MySQL · SQL Query Writing · Data Filtering · Data Cleaning · Aggregation · JOINs · Subqueries · CASE Statements · String Functions · Date Functions · GROUP BY · HAVING · Window Functions**

---

## 🎯 Learning Outcome

Through this practice, I strengthened my ability to:

- Convert business-style questions into SQL queries.
- Filter data using multiple conditions.
- Handle `NULL` values correctly.
- Perform aggregation and grouped analysis.
- Join related hospital tables.
- Work with dates and years.
- Use conditional logic with `CASE`.
- Detect duplicate and repeated records.
- Calculate percentages and differences.
- Apply analytical and window functions.

---

## 👨‍💻 Author

**Harsh Sharma**  
Aspiring Data Analyst

**Skills:** SQL · Python · Excel · Power BI · Tableau · MongoDB

---

> **Note:** The question descriptions and screenshots in this repository are based on my completed SQL practice shown in the provided practice screenshots.
