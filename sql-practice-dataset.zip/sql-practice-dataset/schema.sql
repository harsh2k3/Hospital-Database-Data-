-- ============================================================
-- SQL Practice — Hospital Database schema
-- Matches the structure used on sql-practice.com
-- ============================================================

CREATE TABLE province_names (
    province_id     CHAR(2) PRIMARY KEY,
    province_name   VARCHAR(30)
);

CREATE TABLE doctors (
    doctor_id       INTEGER PRIMARY KEY,
    first_name      VARCHAR(30),
    last_name       VARCHAR(30),
    specialty       VARCHAR(25)
);

CREATE TABLE patients (
    patient_id      INTEGER PRIMARY KEY,
    first_name      VARCHAR(30),
    last_name       VARCHAR(30),
    gender          CHAR(1),
    birth_date      DATE,
    city            VARCHAR(30),
    province_id     CHAR(2) REFERENCES province_names(province_id),
    allergies       VARCHAR(80),
    height          DECIMAL(3,0),
    weight          DECIMAL(4,0)
);

CREATE TABLE admissions (
    admission_id        INTEGER PRIMARY KEY,
    patient_id          INT REFERENCES patients(patient_id),
    admission_date      DATE,
    discharge_date      DATE,
    diagnosis           VARCHAR(50),
    attending_doctor_id INT REFERENCES doctors(doctor_id)
);
