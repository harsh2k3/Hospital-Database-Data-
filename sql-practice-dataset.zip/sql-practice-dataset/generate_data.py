"""
Generates a synthetic hospital dataset matching the schema used on
sql-practice.com, for use as SQL practice / portfolio data on GitHub.

Tables: province_names, doctors, patients, admissions
"""
import csv
import random
from datetime import date, timedelta
from faker import Faker

fake = Faker("en_CA")
random.seed(42)
Faker.seed(42)

OUT = "."

# ---------------------------------------------------------------
# province_names
# ---------------------------------------------------------------
provinces = [
    ("AB", "Alberta"), ("BC", "British Columbia"), ("MB", "Manitoba"),
    ("NB", "New Brunswick"), ("NL", "Newfoundland and Labrador"),
    ("NS", "Nova Scotia"), ("NT", "Northwest Territories"),
    ("NU", "Nunavut"), ("ON", "Ontario"), ("PE", "Prince Edward Island"),
    ("QC", "Quebec"), ("SK", "Saskatchewan"), ("YT", "Yukon"),
]

with open(f"{OUT}/province_names.csv", "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["province_id", "province_name"])
    w.writerows(provinces)

province_ids = [p[0] for p in provinces]

# ---------------------------------------------------------------
# doctors
# ---------------------------------------------------------------
specialties = [
    "Cardiology", "Neurology", "Pediatrics", "Oncology", "General Surgery",
    "Internal Medicine", "Radiology", "Emergency Medicine", "Psychiatry",
    "Orthopedics", "Dermatology", "Anesthesiology", "Family Medicine",
]

N_DOCTORS = 40
doctors = []
for doctor_id in range(1, N_DOCTORS + 1):
    doctors.append((
        doctor_id,
        fake.first_name(),
        fake.last_name(),
        random.choice(specialties),
    ))

with open(f"{OUT}/doctors.csv", "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["doctor_id", "first_name", "last_name", "specialty"])
    w.writerows(doctors)

# ---------------------------------------------------------------
# patients
# ---------------------------------------------------------------
allergy_options = [
    "Penicillin", "Peanuts", "Latex", "Shellfish", "Pollen", "Dust",
    "Aspirin", "Sulfa drugs", "Bee stings", "Ibuprofen", None, None, None,
]

N_PATIENTS = 150
patients = []
for patient_id in range(1, N_PATIENTS + 1):
    gender = random.choice(["M", "F"])
    first = fake.first_name_male() if gender == "M" else fake.first_name_female()
    birth = fake.date_of_birth(minimum_age=0, maximum_age=95)
    height = random.randint(45, 200) if random.random() > 0.10 else ""   # ~10% NULL
    weight = random.randint(3, 150) if random.random() > 0.10 else ""    # ~10% NULL
    allergy = random.choice(allergy_options) if random.random() > 0.35 else ""  # ~35% NULL
    patients.append((
        patient_id,
        first,
        fake.last_name(),
        gender,
        birth.isoformat(),
        fake.city(),
        random.choice(province_ids),
        allergy or "",
        height,
        weight,
    ))

with open(f"{OUT}/patients.csv", "w", newline="") as f:
    w = csv.writer(f)
    w.writerow([
        "patient_id", "first_name", "last_name", "gender", "birth_date",
        "city", "province_id", "allergies", "height", "weight",
    ])
    w.writerows(patients)

# ---------------------------------------------------------------
# admissions
# ---------------------------------------------------------------
diagnoses = [
    "Hypertension", "Type 2 Diabetes", "Pneumonia", "Fracture - Femur",
    "Appendicitis", "Asthma exacerbation", "Myocardial Infarction",
    "Stroke", "Kidney Stones", "Gastroenteritis", "COPD", "Migraine",
    "Sepsis", "Anemia", "Depression", "Anxiety Disorder",
]

start_range = date(2018, 1, 1)
end_range = date(2024, 12, 31)
span_days = (end_range - start_range).days

N_ADMISSIONS = 300
admissions = []
for admission_id in range(1, N_ADMISSIONS + 1):
    admit_date = start_range + timedelta(days=random.randint(0, span_days))
    stay_len = random.randint(0, 21)
    discharge_date = admit_date + timedelta(days=stay_len)
    # ~5% still admitted / missing discharge date
    discharge_str = discharge_date.isoformat() if random.random() > 0.05 else ""
    diagnosis = random.choice(diagnoses) if random.random() > 0.02 else ""  # ~2% NULL
    admissions.append((
        admission_id,
        random.randint(1, N_PATIENTS),
        admit_date.isoformat(),
        discharge_str,
        diagnosis,
        random.randint(1, N_DOCTORS),
    ))

with open(f"{OUT}/admissions.csv", "w", newline="") as f:
    w = csv.writer(f)
    w.writerow([
        "admission_id", "patient_id", "admission_date", "discharge_date",
        "diagnosis", "attending_doctor_id",
    ])
    w.writerows(admissions)

print("Done:")
print(f"  province_names.csv -> {len(provinces)} rows")
print(f"  doctors.csv        -> {len(doctors)} rows")
print(f"  patients.csv       -> {len(patients)} rows")
print(f"  admissions.csv     -> {len(admissions)} rows")
